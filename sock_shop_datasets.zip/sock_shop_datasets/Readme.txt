raw_data : 原始采集数据，有异常多分类需求就自己对其进行处理
process_data : 处理后的数据，标签仅包含0（正常）/1（异常），可直接用于异常检测
Data_description : 原始采集数据的背景和方法说明
Modify_description : 对原始数据做了适合时序异常检测模型使用的改动说明 