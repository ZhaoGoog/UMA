export CUDA_VISIBLE_DEVICES=0

model_name=E

#python -u run.py \
#  --task_name imputation \
#  --is_training 1 \
#  --root_path ./dataset/ETT-small/ \
#  --data_path ETTm2.csv \
#  --model_id ETTm2_mask_0.125 \
#  --mask_rate 0.125 \
#  --model $model_name \
#  --data ETTm2 \
#  --features M \
#  --seq_len 96 \
#  --label_len 0 \
#  --pred_len 0 \
#  --e_layers 2 \
#  --d_layers 1 \
#  --factor 3 \
#  --enc_in 7 \
#  --dec_in 7 \
#  --c_out 7 \
#  --batch_size 16 \
#  --d_model 64 \
#  --d_ff 64 \
#  --des 'Exp' \
#  --itr 1 \
#  --top_k 3 \
#  --lradj  type3 \
#  --learning_rate 0.001
#
#python -u run.py \
#  --task_name imputation \
#  --is_training 1 \
#  --root_path ./dataset/ETT-small/ \
#  --data_path ETTm2.csv \
#  --model_id ETTm2_mask_0.25 \
#  --mask_rate 0.25 \
#  --model $model_name \
#  --data ETTm2 \
#  --features M \
#  --seq_len 96 \
#  --label_len 0 \
#  --pred_len 0 \
#  --e_layers 2 \
#  --d_layers 1 \
#  --factor 3 \
#  --enc_in 7 \
#  --dec_in 7 \
#  --c_out 7 \
#  --batch_size 16 \
#  --d_model 64 \
#  --d_ff 64 \
#  --des 'Exp' \
#  --itr 1 \
#  --top_k 3 \
#  --lradj  type3 \
#  --learning_rate 0.001

#python -u run.py \
#  --task_name imputation \
#  --is_training 1 \
#  --root_path ./dataset/ETT-small/ \
#  --data_path ETTm2.csv \
#  --model_id ETTm2_mask_0.375 \
#  --mask_rate 0.375 \
#  --model $model_name \
#  --data ETTm2 \
#  --features M \
#  --seq_len 96 \
#  --label_len 0 \
#  --pred_len 0 \
#  --e_layers 2 \
#  --d_layers 1 \
#  --factor 3 \
#  --enc_in 7 \
#  --dec_in 7 \
#  --c_out 7 \
#  --batch_size 16 \
#  --d_model 64 \
#  --d_ff 64 \
#  --des 'Exp' \
#  --itr 1 \
#  --top_k 3 \
#  --lradj  type3 \
#  --learning_rate 0.001
#
#python -u run.py \
#  --task_name imputation \
#  --is_training 1 \
#  --root_path ./dataset/ETT-small/ \
#  --data_path ETTm2.csv \
#  --model_id ETTm2_mask_0.5 \
#  --mask_rate 0.5 \
#  --model $model_name \
#  --data ETTm2 \
#  --features M \
#  --seq_len 96 \
#  --label_len 0 \
#  --pred_len 0 \
#  --e_layers 2 \
#  --d_layers 1 \
#  --factor 3 \
#  --enc_in 7 \
#  --dec_in 7 \
#  --c_out 7 \
#  --batch_size 16 \
#  --d_model 64 \
#  --d_ff 64 \
#  --des 'Exp' \
#  --itr 1 \
#  --top_k 3 \
#  --lradj  type3 \
#  --learning_rate 0.001

