import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.fft
import lightning as L
from layers.Embed import DataEmbedding
from layers.Conv_Blocks import Inception_Block_V1,Inception_Block_V2
from layers.Embed import PatchEmbedding
from layers.Autoformer_EncDec import series_decomp

def FFT_for_Period(x, k=2):
    # [B, T, C]
    xf = torch.fft.rfft(x, dim=1)
    # find period by amplitudes
    frequency_list = abs(xf).mean(0).mean(-1)
    frequency_list[0] = 0
    _, top_list = torch.topk(frequency_list, k)
    top_list = top_list.detach().cpu().numpy()
    period = x.shape[1] // top_list
    return period, abs(xf).mean(-1)[:, top_list]
class AxialBlock(nn.Module):
    def __init__(self, configs):
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(configs.d_model, configs.n_heads,
                                                   dim_feedforward=4 * configs.d_model, batch_first=True)
        self.attn_p = nn.TransformerEncoder(encoder_layer, num_layers=configs.e_layers)
        self.norm1 = nn.LayerNorm(configs.d_model)
        self.norm2 = nn.LayerNorm(configs.d_model)
        self.norm = nn.LayerNorm(configs.d_model)
        self.proj = nn.Linear(configs.d_model, configs.d_model)
        self.drop = nn.Dropout(configs.dropout)

        self.local_conv1 = nn.Conv1d(configs.d_model, configs.d_model, kernel_size=1)
        self.local_conv2 = nn.Conv1d(configs.d_model, configs.d_model, kernel_size=3, padding=1)
        self.local_conv3 = nn.Conv1d(configs.d_model, configs.d_model, kernel_size=5, padding=2)
        self.local_conv4 = nn.Conv1d(configs.d_model, configs.d_model, kernel_size=7, padding=3)
        self.local_conv5 = nn.Conv1d(configs.d_model, configs.d_model, kernel_size=9, padding=4)


        self.pw_fuse = nn.Conv1d(configs.d_model * 5, configs.d_model, kernel_size=1)

    def forward(self, x):  # [B, C, P, D]
        B, C, M, P = x.shape
        # 周期 内 conv
        x_d = x.permute(0, 2, 1, 3).reshape(B * M, C, P)
        local1 = self.local_conv1(x_d)
        local2 = self.local_conv2(x_d)
        local3 = self.local_conv3(x_d)
        local4 = self.local_conv4(x_d)
        local5 = self.local_conv5(x_d)
        # local6 = self.local_conv6(x_d)

        m_cat = torch.cat([local1, local2, local3, local4, local5], dim=1)
        m_fuse = self.pw_fuse(m_cat)
        out_d = F.gelu(m_fuse + x_d)
        out_d = out_d.reshape(B, M, C, P).permute(0, 2, 1, 3)  # B C F P
        out_d = self.norm1(out_d.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)  # B f p C ==> B C f p

        #周期 间 attention
        x_p = x.permute(0, 3, 1, 2).reshape(B * P, C, M).permute(0, 2, 1)
        out_p = self.attn_p(x_p)
        out_p = out_p.permute(0, 2, 1).reshape(B, P, C, M).permute(0, 2, 3, 1) #B C f p
        out_p = self.norm2(out_p.permute(0, 2, 3, 1)).permute(0, 3, 1, 2) #B f p C==> B C f p
        out = (out_p + out_d).permute(0, 2, 3, 1)
        # 融合
        out = self.drop(self.proj(out)) #B f p C
        return self.norm(out).permute(0, 3, 1, 2)

class TimesBlock(nn.Module):
    def __init__(self, configs):
        super(TimesBlock, self).__init__()
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.k = configs.top_k
        # parameter-efficient design
        self.att = AxialBlock(configs)

    def forward(self, x):
        B, T, N = x.size()
        period_list, period_weight = FFT_for_Period(x, self.k)

        res = []
        for i in range(self.k):
            period = period_list[i]
            # padding
            if self.seq_len % period != 0:
                length = (
                                 (self.seq_len // period) + 1) * period
                padding = torch.zeros([x.shape[0], (length - self.seq_len), x.shape[2]]).to(x.device)
                out = torch.cat([x, padding], dim=1)
            else:
                length = self.seq_len
                out = x
            # reshape
            out = out.reshape(B, length // period, period,
                              N).permute(0, 3, 1, 2).contiguous()
            # 2D conv: from 1d Variation to 2d Variation
            out = self.att(out)
            # reshape back
            out = out.permute(0, 2, 3, 1).reshape(B, -1, N)
            res.append(out[:, :self.seq_len, :])
        res = torch.stack(res, dim=-1)
        # adaptive aggregation
        period_weight = F.softmax(period_weight, dim=1)
        period_weight = period_weight.unsqueeze(
            1).unsqueeze(1).repeat(1, T, N, 1)
        res = torch.sum(res * period_weight, -1)
        # residual connection
        res = res + x
        return res
class ICB(L.LightningModule):
    def __init__(self, configs, in_features, out_features, dropout=0.1):
        super().__init__()
        self.conv1 = nn.Conv1d(configs.d_model, configs.d_model * 4, 1)
        self.conv2 = nn.Conv1d(configs.d_model, configs.d_model * 4, 3, 1, padding=1)

        self.conv3 = nn.Conv1d(configs.d_model * 4, configs.d_model, 1)
        self.conv4 = nn.Conv1d(configs.d_model * 4, configs.d_model, 3, 1, padding=1)

        self.drop = nn.Dropout(dropout)
        self.act = nn.GELU()
        if configs.task_name == 'long_term_forecast' or configs.task_name == 'short_term_forecast':
             self.trend = nn.Linear(configs.seq_len, configs.pred_len)
        else :self.trend = nn.Linear(configs.seq_len, configs.seq_len)
    def forward(self, x):
        x = x.transpose(1, 2)
        x1 = self.drop(self.act(self.conv1(x)))
        x2 = self.drop(self.act(self.conv2(x)))
        conv_x1 = torch.stack([x1, x2], dim=-1).mean(-1)

        x3 = self.drop(self.act(self.conv3(conv_x1)))
        x4 = self.drop(self.act(self.conv4(conv_x1)))
        conv_x2 = torch.stack([x3, x4], dim=-1).mean(-1)

        x_trend = self.trend(conv_x2)
        x = x_trend.transpose(1, 2)
        return x

class PatchBlock(nn.Module):
    def __init__(self, configs):
        super(PatchBlock, self).__init__()
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        # parameter-efficient design

        self.conv = nn.Sequential(
            Inception_Block_V1(configs.d_model, configs.d_ff,
                               num_kernels=configs.num_kernels),
            nn.GELU(),
            Inception_Block_V2(configs.d_ff, configs.d_model,
                               num_kernels=configs.num_kernels)
        )


    def forward(self, x):
        out = self.conv(x)
        return out


class Model(nn.Module):

    def __init__(self, configs):
        super(Model, self).__init__()
        self.configs = configs
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len
        self.pred_len = configs.pred_len
        self.stride = configs.patch_len // 2
        self.Solar = configs.data
        self.padding = 0
        self.num_patches = int((configs.seq_len - configs.patch_len) / self.stride + 1)
        self.patch_embedding = PatchEmbedding(configs.d_model,
                                            configs.patch_len,
                                            self.stride,
                                            self.padding,
                                            configs.dropout)

        self.decompsition = series_decomp(configs.moving_avg)


        self.patch = nn.ModuleList([PatchBlock(configs)
                                    for _ in range(configs.e_layers)])

        self.model = nn.ModuleList([TimesBlock(configs)
                                    for _ in range(configs.e_layers)])

        self.enc_embedding = DataEmbedding(configs.enc_in, configs.d_model, configs.embed, configs.freq,
                                           configs.dropout)
        self.icb = ICB(configs, configs.enc_in, configs.d_model, configs.dropout)
        self.layer = configs.e_layers

        self.layer_norm = nn.LayerNorm(configs.d_model)
        if self.task_name == 'long_term_forecast' or self.task_name == 'short_term_forecast':
            self.projection1 = nn.Linear(
                configs.d_model * self.num_patches, self.pred_len)
            self.projection2 = nn.Linear(
                configs.seq_len, self.pred_len)
            self.projection = nn.Linear(
                configs.d_model, configs.c_out, bias=True)
        if self.task_name == 'imputation' or self.task_name == 'anomaly_detection':
            self.projection1 = nn.Linear(
                configs.d_model * self.num_patches, self.seq_len)
            self.projection = nn.Linear(
                configs.d_model, configs.c_out, bias=True)
        if self.task_name == 'classification':
            self.projection1 = nn.Linear(
                configs.d_model * self.num_patches, self.seq_len)
            self.act = F.gelu
            self.dropout = nn.Dropout(configs.dropout)
            self.projection = nn.Linear(
                configs.d_model * configs.seq_len, configs.num_class)


    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        # Normalization from Non-stationary Transformer

        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc.sub(means)
        stdev = torch.sqrt(
            torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc.div(stdev)

        # patch_x = x_enc + self.temporal(x_enc.transpose(1, 2)).transpose(1, 2)
        # patch_x = patch_x + self.channel(patch_x)
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        x_seansoanl, x_trend = self.decompsition(enc_out)
        x_trend = self.icb(x_trend)

        # embedding
        patch_out = self.patch_embedding(x_seansoanl)  # [B,T,C]
        for i in range(self.layer):
            patch_out = self.layer_norm(self.patch[i](patch_out))
        B, C, P, D = patch_out.shape
        patch_out = patch_out.view(B, C, P * D)
        patch_out = self.projection1(patch_out).permute(0, 2, 1)
        patch_out = patch_out + x_trend
        patch_out = self.projection(patch_out)


        # embedding
        # enc_out = self.enc_embedding(x_enc, x_mark_enc)  # [B,T,C]
        for i in range(self.layer):
            enc_out = self.layer_norm(self.model[i](enc_out))
        dec_out = self.projection2(enc_out.permute(0, 2, 1)).permute(0, 2, 1)
        dec_out = self.projection(dec_out)
        dec_out = dec_out + patch_out

        # De-Normalization from Non-stationary Transformer
        dec_out = dec_out.mul(
                  (stdev[:, 0, :].unsqueeze(1).repeat(
                      1, self.pred_len, 1)))
        dec_out = dec_out.add(
                  (means[:, 0, :].unsqueeze(1).repeat(
                      1, self.pred_len, 1)))
        return dec_out


    def imputation(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask):
        # Normalization from Non-stationary Transformer
        means = torch.sum(x_enc, dim=1) / torch.sum(mask == 1, dim=1)
        means = means.unsqueeze(1).detach()
        x_enc = x_enc.sub(means)
        x_enc = x_enc.masked_fill(mask == 0, 0)
        stdev = torch.sqrt(torch.sum(x_enc * x_enc, dim=1) /
                           torch.sum(mask == 1, dim=1) + 1e-5)
        stdev = stdev.unsqueeze(1).detach()
        x_enc = x_enc.div(stdev)

        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        x_seansoanl, x_trend = self.decompsition(enc_out)
        x_trend = self.icb(x_trend)

        # embedding
        patch_out = self.patch_embedding(x_seansoanl)  # [B,T,C]
        for i in range(self.layer):
            patch_out = self.layer_norm(self.patch[i](patch_out))
        B, C, P, D = patch_out.shape
        patch_out = patch_out.view(B, C, P * D)
        patch_out = self.projection1(patch_out).permute(0, 2, 1)
        patch_out = patch_out + x_trend
        patch_out = self.projection(patch_out)

        # embedding
        # enc_out = self.enc_embedding(x_enc, x_mark_enc)  # [B,T,C]
        for i in range(self.layer):
            enc_out = self.layer_norm(self.model[i](enc_out))
        # dec_out = self.projection2(enc_out.permute(0, 2, 1)).permute(0, 2, 1)
        dec_out = self.projection(enc_out)

        dec_out = dec_out + patch_out

        # De-Normalization from Non-stationary Transformer
        dec_out = dec_out.mul(
                  (stdev[:, 0, :].unsqueeze(1).repeat(
                      1, self.pred_len + self.seq_len, 1)))
        dec_out = dec_out.add(
                  (means[:, 0, :].unsqueeze(1).repeat(
                      1, self.pred_len + self.seq_len, 1)))
        return dec_out

    def anomaly_detection(self, x_enc):
        # Normalization from Non-stationary Transformer
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc.sub(means)
        stdev = torch.sqrt(
            torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc.div(stdev)

        enc_out = self.enc_embedding(x_enc, None)
        x_seansoanl, x_trend = self.decompsition(enc_out)
        x_trend = self.icb(x_trend)

        # embedding
        patch_out = self.patch_embedding(x_seansoanl)  # [B,T,C]
        for i in range(self.layer):
            patch_out = self.layer_norm(self.patch[i](patch_out))
        B, C, P, D = patch_out.shape
        patch_out = patch_out.view(B, C, P * D)
        patch_out = self.projection1(patch_out).permute(0, 2, 1)
        patch_out = patch_out + x_trend
        patch_out = self.projection(patch_out)

        # embedding
        # enc_out = self.enc_embedding(x_enc, x_mark_enc)  # [B,T,C]
        for i in range(self.layer):
            enc_out = self.layer_norm(self.model[i](enc_out))
        # dec_out = self.projection2(enc_out.permute(0, 2, 1)).permute(0, 2, 1)
        dec_out = self.projection(enc_out)

        dec_out = dec_out + patch_out

        # De-Normalization from Non-stationary Transformer
        dec_out = dec_out.mul(
                  (stdev[:, 0, :].unsqueeze(1).repeat(
                      1, self.pred_len + self.seq_len, 1)))
        dec_out = dec_out.add(
                  (means[:, 0, :].unsqueeze(1).repeat(
                      1, self.pred_len + self.seq_len, 1)))
        return dec_out

    def classification(self, x_enc, x_mark_enc):
        enc_out = self.enc_embedding(x_enc, None)
        x_seansoanl, x_trend = self.decompsition(enc_out)
        x_trend = self.icb(x_trend)

        # embedding
        patch_out = self.patch_embedding(x_seansoanl)  # [B,T,C]
        for i in range(self.layer):
            patch_out = self.layer_norm(self.patch[i](patch_out))
        B, C, P, D = patch_out.shape
        patch_out = patch_out.view(B, C, P * D)
        patch_out = self.projection1(patch_out).permute(0, 2, 1)
        patch_out = patch_out + x_trend

        # embedding
        # enc_out = self.enc_embedding(x_enc, x_mark_enc)  # [B,T,C]
        for i in range(self.layer):
            enc_out = self.layer_norm(self.model[i](enc_out))
        # dec_out = self.projection2(enc_out.permute(0, 2, 1)).permute(0, 2, 1)

        dec_out = enc_out + patch_out

        output = self.act(dec_out)
        output = self.dropout(output)
        # zero-out padding embeddings
        output = output * x_mark_enc.unsqueeze(-1)
        # (batch_size, seq_length * d_model)
        output = output.reshape(output.shape[0], -1)
        output = self.projection(output)  # (batch_size, num_classes)
        return output


    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name == 'long_term_forecast' or self.task_name == 'short_term_forecast':
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]  # [B, L, D]
        if self.task_name == 'imputation':
            dec_out = self.imputation(
                x_enc, x_mark_enc, x_dec, x_mark_dec, mask)
            return dec_out  # [B, L, D]
        if self.task_name == 'anomaly_detection':
            dec_out = self.anomaly_detection(x_enc)
            return dec_out  # [B, L, D]
        if self.task_name == 'classification':
            dec_out = self.classification(x_enc, x_mark_enc)
            return dec_out  # [B, N]
        return None